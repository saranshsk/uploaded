#!/usr/bin/python

from subprocess import Popen, PIPE
import cx_Oracle
import csv
import sys

def insert_data (dff_path, dff_validation_rs):
    
    print(dff_path)
    for rs_dict in dff_validation_rs:
	start_insert_module ( dff_path, rs_dict['DFF_FILE_DELIM'])

def start_insert_module (dff_path, DFF_FILE_DELIM):
    column_string=""
    values_string=""
    insert_query_1=""
    var=","
    csv.field_size_limit(sys.maxsize)
    reader = csv.reader(open(dff_path,"r"))
    lines=[]
    for line in reader:
        lines.append(line)
    #print lines
    validation_cmd = "awk -F'<INP_DELIM>' '{print NF;exit}' <INP>"
    validation_cmd = validation_cmd.replace('<INP>', dff_path)
    validation_cmd = validation_cmd.replace('<INP_DELIM>', DFF_FILE_DELIM)
    print(validation_cmd)
    print "Executing the above command for extracting the column count from the file"
    p = Popen ( validation_cmd, shell = True, stdout = PIPE, stderr = PIPE )
    validation_cmd_result, err = p.communicate()
    print "Execution return code: ", p.returncode
    print validation_cmd_result.rstrip(), err.rstrip()
    if p.returncode == 0:
        column_count = int(validation_cmd_result.rstrip())
        for x in range(1, column_count+1):
            if x < column_count:
                column_string = column_string+'c'+str(x)+','
                values_string = values_string+':'+str(x)+','
            if  x==column_count:
                column_string = column_string+'c'+str(x)
                values_string = values_string+':'+str(x)
        #print column_string
        #print values_string
        insert_query_1 = "insert into table1 (" + column_string + ") values ( " + values_string +")"
        #print insert_query_1
    repo_db_conn = cx_Oracle.connect ( 'metadata/METADATA@xe' )
    cur=repo_db_conn.cursor()
    for line in lines:
        #print(line)
        cur.executemany(insert_query_1,lines)
        repo_db_conn.commit()
        cur.close()
