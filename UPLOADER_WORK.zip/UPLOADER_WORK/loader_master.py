#!/usr/bin/python

import mddetl

from mddetl import dff_call_func_to_get_data

print ("The program starts at this point")
dff_call_func_to_get_data.dataingest ( u'1' )

print ("The program has ended. Refer log file for more information")

