#!/usr/bin/python

import os
from subprocess import Popen, PIPE
import cx_Oracle
import csv

column_count = 10
string=""
var=","
for x in range(1, column_count+1):
    #print 'c'+str(x)+',',
    if x < 10:
        string = string+'c'+str(x)+','
    if  x==10:
        string = string+'c'+str(x)
print string